como compilar
    make

como executar
    ./main <num_threads>

bibliotecas
    stdio
    pthread - utilização de pthreads
    unistd - POSIX
    stdlib
    time.h - calcular tempo de execução